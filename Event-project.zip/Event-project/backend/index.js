const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const app = express();
const PORT = process.env.PORT || 5000;
const JWT_SECRET = 'hello-jii'; 

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/eventmanager')
.then(() => console.log('MongoDB connected'))
.catch(err => console.error('MongoDB connection error:', err));

// Define Schemas
const UserSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

const EventSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  date: { type: Date, required: true },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  createdAt: { type: Date, default: Date.now }
});

const RegistrationSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  event: { type: mongoose.Schema.Types.ObjectId, ref: 'Event', required: true },
  registeredAt: { type: Date, default: Date.now }
});

// Create a compound index to prevent duplicate registrations
RegistrationSchema.index({ user: 1, event: 1 }, { unique: true });

// Define Models
const User = mongoose.model('User', UserSchema);
const Event = mongoose.model('Event', EventSchema);
const Registration = mongoose.model('Registration', RegistrationSchema);

// Authentication Middleware
const auth = async (req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = { _id: decoded._id };
    next();
  } catch (error) {
    res.status(401).send({ error: 'Please authenticate.' });
  }
};

// API Routes

// User Registration
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    
    // Check if user already exists
    const existingUser = await User.findOne({ $or: [{ email }, { username }] });
    if (existingUser) {
      return res.status(400).json({ message: 'Username or email already exists' });
    }
    
    // Hash password
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);
    
    // Create new user
    const user = new User({
      username,
      email,
      password: hashedPassword
    });
    
    await user.save();
    
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// User Login
app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    // Find user
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Validate password
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: 'Invalid credentials' });
    }
    
    // Generate JWT
    const token = jwt.sign({ _id: user._id }, JWT_SECRET, { expiresIn: '24h' });
    
    res.json({
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create Event
app.post('/api/events', auth, async (req, res) => {
  try {
    const { title, description, date } = req.body;
    
    // Validate future date
    const eventDate = new Date(date);
    if (eventDate <= new Date()) {
      return res.status(400).json({ message: 'Event date must be in the future' });
    }
    
    const event = new Event({
      title,
      description,
      date: eventDate,
      createdBy: req.user._id
    });
    
    await event.save();
    res.status(201).json(event);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get All Events
app.get('/api/events', async (req, res) => {
  try {
    // Get only upcoming events
    const events = await Event.find({ date: { $gte: new Date() } })
      .sort({ date: 1 })
      .populate('createdBy', 'username');
    
    res.json(events);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Register for Event
app.post('/api/events/:eventId/register', auth, async (req, res) => {
  try {
    const eventId = req.params.eventId;
    const userId = req.user._id;
    
    // Check if event exists and is in the future
    const event = await Event.findById(eventId);
    if (!event) {
      return res.status(404).json({ message: 'Event not found' });
    }
    
    if (event.date <= new Date()) {
      return res.status(400).json({ message: 'Cannot register for past events' });
    }
    
    // Check if already registered
    const existingRegistration = await Registration.findOne({
      user: userId,
      event: eventId
    });
    
    if (existingRegistration) {
      return res.status(400).json({ message: 'Already registered for this event' });
    }
    
    // Create registration
    const registration = new Registration({
      user: userId,
      event: eventId
    });
    
    await registration.save();
    res.status(201).json({ message: 'Registration successful' });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Already registered for this event' });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get User's Registered Events
app.get('/api/users/:userId/events', auth, async (req, res) => {
  try {
    const userId = req.params.userId;
    
    // Ensure user can only access their own registrations
    if (userId !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to access this data' });
    }
    
    const registrations = await Registration.find({ user: userId })
      .populate({
        path: 'event',
        select: 'title description date createdBy',
        populate: {
          path: 'createdBy',
          select: 'username'
        }
      });
    
    const events = registrations.map(reg => reg.event);
    res.json(events);
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Cancel Registration
app.delete('/api/events/:eventId/cancel/:userId', auth, async (req, res) => {
  try {
    const { eventId, userId } = req.params;
    
    // Ensure user can only cancel their own registrations
    if (userId !== req.user._id.toString()) {
      return res.status(403).json({ message: 'Not authorized to perform this action' });
    }
    
    const result = await Registration.findOneAndDelete({
      user: userId,
      event: eventId
    });
    
    if (!result) {
      return res.status(404).json({ message: 'Registration not found' });
    }
    
    res.json({ message: 'Registration cancelled successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
