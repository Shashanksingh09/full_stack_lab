import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL
});

// Add token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

export const registerUser = async (userData) => {
  return api.post('/auth/register', userData);
};

export const loginUser = async (credentials) => {
  return api.post('/auth/login', credentials);
};

export const getAllEvents = async () => {
  return api.get('/events');
};

export const createEvent = async (eventData) => {
  return api.post('/events', eventData);
};

export const registerForEvent = async (eventId) => {
  return api.post(`/events/${eventId}/register`);
};

export const getUserEvents = async (userId) => {
  return api.get(`/users/${userId}/events`);
};

export const cancelRegistration = async (eventId, userId) => {
  return api.delete(`/events/${eventId}/cancel/${userId}`);
};
