import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="jumbotron">
      <h1 className="display-4">Welcome to Event Manager</h1>
      <p className="lead">
        Register for events or create your own! Join our community of event organizers and attendees.
      </p>
      <hr className="my-4" />
      <p>Browse upcoming events or create a new one if you're logged in.</p>
      <Link to="/events" className="btn btn-primary me-2">Browse Events</Link>
      <Link to="/register" className="btn btn-success">Sign Up</Link>
    </div>
  );
};

export default Home;