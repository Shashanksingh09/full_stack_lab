import React, { useState, useEffect } from 'react';
import { getUserEvents, cancelRegistration } from '../services/api';
import { useAuth } from '../context/AuthContext';

const MyEvents = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const { user } = useAuth();
  
  useEffect(() => {
    const fetchUserEvents = async () => {
      try {
        const response = await getUserEvents(user.id);
        setEvents(response.data);
      } catch (err) {
        setError('Failed to load your events');
      } finally {
        setLoading(false);
      }
    };
    
    if (user) {
      fetchUserEvents();
    }
  }, [user]);
  
  const handleCancelRegistration = async (eventId) => {
    setError('');
    setSuccessMsg('');
    
    try {
      await cancelRegistration(eventId, user.id);
      // Remove event from state
      setEvents(events.filter(event => event._id !== eventId));
      setSuccessMsg('Registration cancelled successfully');
    } catch (err) {
      setError(err.response?.data?.message || 'Failed to cancel registration');
    }
  };
  
  if (loading) {
    return <div className="text-center">Loading your events...</div>;
  }
  
  return (
    <div>
      <h2>My Registered Events</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      {successMsg && <div className="alert alert-success">{successMsg}</div>}
      
      {events.length === 0 ? (
        <p>You haven't registered for any events yet.</p>
      ) : (
        <div className="row">
          {events.map((event) => (
            <div className="col-md-4 mb-4" key={event._id}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{event.title}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">
                    {new Date(event.date).toLocaleDateString()}
                  </h6>
                  <p className="card-text">{event.description}</p>
                  <p className="card-text">
                    <small className="text-muted">
                      Posted by: {event.createdBy?.username || 'Anonymous'}
                    </small>
                  </p>
                  <button 
                    className="btn btn-danger"
                    onClick={() => handleCancelRegistration(event._id)}
                  >
                    Cancel Registration
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
          </div>
  );
};
export default MyEvents;