import React, { useState, useEffect } from 'react';
import { getAllEvents, registerForEvent } from '../services/api';
import { useAuth } from '../context/AuthContext';

const Events = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  const { isAuthenticated, user } = useAuth();
  
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await getAllEvents();
        setEvents(response.data);
      } catch (err) {
        setError('Failed to load events');
      } finally {
        setLoading(false);
      }
    };
    
    fetchEvents();
  }, []);
  
  const handleRegister = async (eventId) => {
    setError('');
    setSuccessMsg('');
    
    try {
      await registerForEvent(eventId);
      setSuccessMsg('Successfully registered for event');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };
  
  if (loading) {
    return <div className="text-center">Loading events...</div>;
  }
  
  return (
    <div>
      <h2>Upcoming Events</h2>
      {error && <div className="alert alert-danger">{error}</div>}
      {successMsg && <div className="alert alert-success">{successMsg}</div>}
      
      {events.length === 0 ? (
        <p>No upcoming events found.</p>
      ) : (
        <div className="row">
          {events.map((event) => (
            <div className="col-md-4 mb-4" key={event._id}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">{event.title}</h5>
                  <h6 className="card-subtitle mb-2 text-muted">
                    {new Date(event.date).toLocaleDateString()}
                  </h6>
                  <p className="card-text">{event.description}</p>
                  <p className="card-text">
                    <small className="text-muted">
                      Posted by: {event.createdBy?.username || 'Anonymous'}
                    </small>
                  </p>
                  
                  {isAuthenticated ? (
                    <button 
                      className="btn btn-primary"
                      onClick={() => handleRegister(event._id)}
                    >
                      Register
                    </button>
                  ) : (
                    <p className="text-muted">Login to register for this event.</p>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Events;
